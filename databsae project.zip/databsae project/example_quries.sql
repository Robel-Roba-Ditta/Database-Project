-- Questions and SQL Queries

-- How many students are enrolled?
SELECT COUNT(*) FROM student;

-- List all students enrolled in a specific course.
SELECT s.StudentID, s.FirstName, s.LastName 
FROM student s 
JOIN enrollment e ON s.StudentID = e.StudentID 
WHERE e.CourseID = 1;

-- What is the average score for a specific exam?
SELECT AVG(g.Score) 
FROM grade g 
WHERE g.ExamID = 1;

-- List all courses a specific student is enrolled in.
SELECT c.CourseID, c.CourseName 
FROM course c 
JOIN enrollment e ON c.CourseID = e.CourseID 
WHERE e.StudentID = 1;

-- What are the details of students who scored above 90 in any exam?
SELECT s.StudentID, s.FirstName, s.LastName, g.Score 
FROM student s 
JOIN enrollment e ON s.StudentID = e.StudentID 
JOIN grade g ON e.EnrollmentID = g.EnrollmentID 
WHERE g.Score > 90;

-- List the attendance records for a specific student.
SELECT a.AttendanceID, a.Date, a.Status 
FROM attendance a 
JOIN enrollment e ON a.EnrollmentID = e.EnrollmentID 
WHERE e.StudentID = 1;

-- What is the total capacity of all classrooms?
SELECT SUM(Capacity) FROM classroom;

-- List all teachers along with the subjects they teach.
SELECT t.TeacherID, t.FirstName, t.LastName, s.SubjectName 
FROM teacher t 
JOIN subject s ON t.SubjectID = s.SubjectID;

-- How many students are there in each grade level?
SELECT g.GradeName, COUNT(s.StudentID) 
FROM gradelevel g 
JOIN student s ON g.GradeLevelID = s.GradeLevelID 
GROUP BY g.GradeName;

-- List all exams for a specific course.
SELECT e.ExamID, e.ExamDate, e.MaximumScore, e.ExamType 
FROM exam e 
WHERE e.CourseID = 1;

-- What is the average salary of teachers?
SELECT AVG(Salary) FROM teacher;

-- List all students with their parent/guardian details.
SELECT s.StudentID, s.FirstName, s.LastName, p.FirstName AS ParentFirstName, p.LastName AS ParentLastName 
FROM student s 
JOIN parentguardianonly p ON s.ParentGuardianID = p.ParentGuardianID;

-- List all classrooms with their schedules.
SELECT cl.ClassroomID, cl.ClassroomName, cs.DayOfWeek, cs.StartTime, cs.EndTime 
FROM classroom cl 
JOIN classschedule cs ON cl.ClassroomID = cs.ClassroomID;

-- What is the enrollment date for a specific student?
SELECT EnrollmentDate 
FROM enrollment 
WHERE StudentID = 1;

-- List all subjects being taught in a specific section.
SELECT s.SubjectID, s.SubjectName 
FROM subject s 
JOIN course c ON s.SubjectID = c.SubjectID 
WHERE c.SectionID = 1;

-- How many teachers are there for each subject?
SELECT s.SubjectName, COUNT(t.TeacherID) 
FROM subject s 
JOIN teacher t ON s.SubjectID = t.SubjectID 
GROUP BY s.SubjectName;

-- List all courses along with their grade level and section.
SELECT c.CourseID, c.CourseName, g.GradeName, se.SectionName 
FROM course c 
JOIN gradelevel g ON c.GradeLevelID = g.GradeLevelID 
JOIN section se ON c.SectionID = se.SectionID;

-- What is the highest score obtained in a specific exam?
SELECT MAX(g.Score) 
FROM grade g 
WHERE g.ExamID = 1;

-- List all exams scheduled for a specific date.
SELECT e.ExamID, e.CourseID, e.MaximumScore, e.ExamType 
FROM exam e 
WHERE e.ExamDate = '2024-05-20';

-- List the details of students who are absent on a specific date.
SELECT s.StudentID, s.FirstName, s.LastName 
FROM student s 
JOIN enrollment e ON s.StudentID = e.StudentID 
JOIN attendance a ON e.EnrollmentID = a.EnrollmentID 
WHERE a.Date = '2024-05-20' AND a.Status = 'Absent';
-- What is the total number of sections?
SELECT COUNT(*) FROM section;

-- List the details of teachers hired after a specific date.
SELECT TeacherID, FirstName, LastName, HireDate 
FROM teacher 
WHERE HireDate > '2023-01-01';

-- List all students along with their enrolled courses and grades.
SELECT s.StudentID, s.FirstName, s.LastName, c.CourseName, g.Score 
FROM student s 
JOIN enrollment e ON s.StudentID = e.StudentID 
JOIN course c ON e.CourseID = c.CourseID 
JOIN grade g ON e.EnrollmentID = g.EnrollmentID;

-- What is the average score for each course?
SELECT c.CourseName, AVG(g.Score) 
FROM course c 
JOIN enrollment e ON c.CourseID = e.CourseID 
JOIN grade g ON e.EnrollmentID = g.EnrollmentID 
GROUP BY c.CourseName;

-- List all parents/guardians with more than one child enrolled.
SELECT p.ParentGuardianID, p.FirstName, p.LastName, COUNT(s.StudentID) AS ChildrenCount 
FROM parentguardianonly p 
JOIN student s ON p.ParentGuardianID = s.ParentGuardianID 
GROUP BY p.ParentGuardianID 
HAVING ChildrenCount > 1;

-- List all courses taught by a specific teacher.
SELECT c.CourseID, c.CourseName 
FROM course c 
WHERE c.TeacherID = 1;

-- What is the average capacity of classrooms?
SELECT AVG(Capacity) FROM classroom;

-- List all teachers who teach more than one subject.
SELECT t.TeacherID, t.FirstName, t.LastName, COUNT(t.SubjectID) AS SubjectsCount 
FROM teacher t 
GROUP BY t.TeacherID 
HAVING SubjectsCount > 1;

-- What is the total number of students in a specific grade level?
SELECT COUNT(s.StudentID) 
FROM student s 
JOIN gradelevel g ON s.GradeLevelID = g.GradeLevelID 
WHERE g.GradeLevelID = 1;

-- List the attendance status for a specific course on a specific date.
SELECT s.StudentID, s.FirstName, s.LastName, a.Status 
FROM student s 
JOIN enrollment e ON s.StudentID = e.StudentID 
JOIN attendance a ON e.EnrollmentID = a.EnrollmentID 
WHERE e.CourseID = 1 AND a.Date = '2024-05-20';

-- How many students have email addresses ending with 'example.com'?
SELECT COUNT(*) 
FROM student 
WHERE Email LIKE '%@example.com';

-- List all teachers along with their hire date and salary.
SELECT TeacherID, FirstName, LastName, HireDate, Salary 
FROM teacher;

-- What is the total number of enrollments in each course?
SELECT c.CourseName, COUNT(e.EnrollmentID) AS EnrollmentCount 
FROM course c 
JOIN enrollment e ON c.CourseID = e.CourseID 
GROUP BY c.CourseName;

-- List all students enrolled after a specific date.
SELECT s.StudentID, s.FirstName, s.LastName, e.EnrollmentDate 
FROM student s 
JOIN enrollment e ON s.StudentID = e.StudentID 
WHERE e.EnrollmentDate > '2024-01-01';

-- What is the total number of exams conducted for each course?
SELECT c.CourseName, COUNT(e.ExamID) AS ExamCount 
FROM course c 
JOIN exam e ON c.CourseID = e.CourseID 
GROUP BY c.CourseName;

-- List all subjects with their corresponding teachers.
SELECT s.SubjectName, t.FirstName, t.LastName 
FROM subject s 
JOIN teacher t ON s.SubjectID = t.SubjectID;

-- What is the average score of students in a specific section?
SELECT AVG(g.Score) 
FROM grade g 
JOIN enrollment e ON g.EnrollmentID = e.EnrollmentID 
JOIN course c ON e.CourseID = c.CourseID 
WHERE c.SectionID = 1;

-- List all students who have not attended a specific class.
SELECT s.StudentID, s.FirstName, s.LastName 
FROM student s 
JOIN enrollment e ON s.StudentID = e.StudentID 
LEFT JOIN attendance a ON e.EnrollmentID = a.EnrollmentID 
WHERE e.CourseID = 1 AND a.Status IS NULL;

-- What is the average number of students per section?
SELECT AVG(StudentCount) 
FROM (
    SELECT se.SectionID, COUNT(e.StudentID) AS StudentCount 
    FROM section se 
    JOIN course c ON se.SectionID = c.SectionID 
    JOIN enrollment e ON c.CourseID = e.CourseID 
    GROUP BY se.SectionID
) AS SectionStudentCounts;

-- List all courses along with their schedules.
SELECT c.CourseID, c.CourseName, cs.DayOfWeek, cs.StartTime, cs.EndTime 
FROM course c 
JOIN classschedule cs ON c.CourseID = cs.CourseID;

-- What is the average score of a specific student across all exams?
SELECT AVG(g.Score) 
FROM grade g 
JOIN enrollment e ON g.EnrollmentID = e.EnrollmentID 
WHERE e.StudentID = 1;

-- List all teachers who have a salary greater than $50,000.
SELECT TeacherID, FirstName, LastName, Salary 
FROM teacher 
WHERE Salary > 50000;

-- How many courses are there in each section?
SELECT se.SectionName, COUNT(c.CourseID) AS CourseCount 
FROM section se 
JOIN course c ON se.SectionID = c.SectionID 
GROUP BY se.SectionName;

-- List all exams along with the courses they belong to.
SELECT e.ExamID, e.ExamDate, e.MaximumScore, e.ExamType, c.CourseName 
FROM exam e 
JOIN course c ON e.CourseID = c.CourseID;

-- What is the total number of students in each classroom?
SELECT cl.ClassroomName, COUNT(e.StudentID) AS StudentCount 
FROM classroom cl 
JOIN classschedule cs ON cl.ClassroomID = cs.ClassroomID 
JOIN course c ON cs.CourseID = c.CourseID 
JOIN enrollment e ON c.CourseID = e.CourseID 
GROUP BY cl.ClassroomName;

-- List all students along with their section names.
SELECT s.StudentID, s.FirstName, s.LastName, se.SectionName 
FROM student s 
JOIN enrollment e ON s.StudentID = e.StudentID 
JOIN course c ON e.CourseID = c.CourseID 
JOIN section se ON c.SectionID = se.SectionID;

-- What is the total number of male and female students?
SELECT Gender, COUNT(*) AS StudentCount 
FROM student 
GROUP BY Gender;

-- List all students along with their birthdates.
SELECT StudentID, FirstName, LastName, DateOfBirth 
FROM student;

-- What is the total number of courses taught by each teacher?
SELECT t.TeacherID, t.FirstName, t.LastName, COUNT(c.CourseID) AS CourseCount 
FROM teacher t 
JOIN course c ON t.TeacherID = c.TeacherID 
GROUP BY t.TeacherID;

-- List the details of exams conducted after a specific date.
SELECT ExamID, CourseID, ExamDate, MaximumScore, ExamType 
FROM exam 
WHERE ExamDate > '2024-01-01';

-- What is the average score of each student in a specific course?
SELECT s.StudentID, s.FirstName, s.LastName, AVG(g.Score) AS AverageScore 
FROM student s 
JOIN enrollment e ON s.StudentID = e.StudentID 
JOIN grade g ON e.EnrollmentID = g.EnrollmentID 
WHERE e.CourseID = 1 
GROUP BY s.StudentID;

-- List all subjects along with the number of students enrolled.
SELECT s.SubjectName, COUNT(e.StudentID) AS StudentCount 
FROM subject s 
JOIN course c ON s.SubjectID = c.SubjectID 
JOIN enrollment e ON c.CourseID = e.CourseID 
GROUP BY s.SubjectName;

-- What is the total number of students in each classroom on a specific day?
SELECT cl.ClassroomName, COUNT(e.StudentID) AS StudentCount 
FROM classroom cl 
JOIN classschedule cs ON cl.ClassroomID = cs.ClassroomID 
JOIN course c ON cs.CourseID = c.CourseID 
JOIN enrollment e ON c.CourseID = e.CourseID 
WHERE cs.DayOfWeek = 'Monday' 
GROUP BY cl.ClassroomName;

-- List the details of all teachers who teach in a specific classroom.
SELECT t.TeacherID, t.FirstName, t.LastName, cl.ClassroomName 
FROM teacher t 
JOIN course c ON t.TeacherID = c.TeacherID 
JOIN classschedule cs ON c.CourseID = cs.CourseID 
JOIN classroom cl ON cs.ClassroomID = cl.ClassroomID 
WHERE cl.ClassroomID = 1;

-- What is the average score for each section?
SELECT se.SectionName, AVG(g.Score) AS AverageScore 
FROM section se 
JOIN course c ON se.SectionID = c.SectionID 
JOIN enrollment e ON c.CourseID = e.CourseID 
JOIN grade g ON e.EnrollmentID = g.EnrollmentID 
GROUP BY se.SectionName;

-- List all exams with a maximum score greater than 100.
SELECT ExamID, CourseID, ExamDate, MaximumScore, ExamType 
FROM exam 
WHERE MaximumScore > 100;

-- How many students have the last name 'Smith'?
SELECT COUNT(*) 
FROM student 
WHERE LastName = 'Smith';

-- List the details of all students who have a parent/guardian named 'John'.
SELECT s.StudentID, s.FirstName, s.LastName, p.FirstName AS ParentFirstName, p.LastName AS ParentLastName 
FROM student s 
JOIN parentguardianonly p ON s.ParentGuardianID = p.ParentGuardianID 
WHERE p.FirstName = 'John';

-- What is the total number of classrooms in each location?
SELECT Location, COUNT(*) AS ClassroomCount 
FROM classroom 
GROUP BY Location;

-- List all students who were born before a specific date.
SELECT StudentID, FirstName, LastName, DateOfBirth 
FROM student 
WHERE DateOfBirth < '2005-01-01';

-- What is the total number of subjects taught in each section?
SELECT se.SectionName, COUNT(s.SubjectID) AS SubjectCount 
FROM section se 
JOIN course c ON se.SectionID = c.SectionID 
JOIN subject s ON c.SubjectID = s.SubjectID 
GROUP BY se.SectionName;

-- List all courses along with the number of exams conducted.
SELECT c.CourseName, COUNT(e.ExamID) AS ExamCount 
FROM course c 
JOIN exam e ON c.CourseID = e.CourseID 
GROUP BY c.CourseName;

-- What is the total number of students in each section?
SELECT se.SectionName, COUNT(s.StudentID) AS StudentCount 
FROM section se 
JOIN course c ON se.SectionID = c.SectionID 
JOIN enrollment e ON c.CourseID = e.CourseID 
JOIN student s ON e.StudentID = s.StudentID 
GROUP BY se.SectionName;

-- List all teachers along with the number of courses they teach.
SELECT t.TeacherID, t.FirstName, t.LastName, COUNT(c.CourseID) AS CourseCount 
FROM teacher t 
JOIN course c ON t.TeacherID = c.TeacherID 
GROUP BY t.TeacherID;

-- What is the average number of students per classroom?
SELECT AVG(StudentCount) 
FROM (
    SELECT cl.ClassroomID, COUNT(e.StudentID) AS StudentCount 
    FROM classroom cl 
    JOIN classschedule cs ON cl.ClassroomID = cs.ClassroomID 
    JOIN course c ON cs.CourseID = c.CourseID 
    JOIN enrollment e ON c.CourseID = e.CourseID 
    GROUP BY cl.ClassroomID
) AS ClassroomStudentCounts;

-- List all courses along with the number of students enrolled.
SELECT c.CourseName, COUNT(e.StudentID) AS StudentCount 
FROM course c 
JOIN enrollment e ON c.CourseID = e.CourseID 
GROUP BY c.CourseName;

-- What is the total number of students who have attended all classes?
SELECT COUNT(DISTINCT e.StudentID) 
FROM enrollment e 
JOIN attendance a ON e.EnrollmentID = a.EnrollmentID 
WHERE a.Status = 'Present' 
GROUP BY e.StudentID 
HAVING COUNT(a.AttendanceID) = (
    SELECT COUNT(*) 
    FROM classschedule cs 
    JOIN course c ON cs.CourseID = c.CourseID 
    WHERE c.CourseID = e.CourseID
);

-- List all classrooms along with their details.
SELECT ClassroomID, ClassroomName, Capacity, Location 
FROM classroom;

-- What is the average score of students in each subject?
SELECT s.SubjectName, AVG(g.Score) AS AverageScore 
FROM subject s 
JOIN course c ON s.SubjectID = c.SubjectID 
JOIN enrollment e ON c.CourseID = e.CourseID 
JOIN grade g ON e.EnrollmentID = g.EnrollmentID 
GROUP BY s.SubjectName;

-- List all students who have not taken any exams.
SELECT s.StudentID, s.FirstName, s.LastName 
FROM student s 
LEFT JOIN enrollment e ON s.StudentID = e.StudentID 
LEFT JOIN grade g ON e.EnrollmentID = g.EnrollmentID 
WHERE g.GradeID IS NULL;

-- What is the total number of students who have scored above 85 in any exam?
SELECT COUNT(DISTINCT e.StudentID) 
FROM grade g 
JOIN enrollment e ON g.EnrollmentID = e.EnrollmentID 
WHERE g.Score > 85;

-- List all exams scheduled in the current month.
SELECT ExamID, CourseID, ExamDate, MaximumScore, ExamType 
FROM exam 
WHERE MONTH(ExamDate) = MONTH(CURDATE()) 
AND YEAR(ExamDate) = YEAR(CURDATE());

-- What is the total number of students who have failed any exam (score below 50)?
SELECT COUNT(DISTINCT e.StudentID) 
FROM grade g 
JOIN enrollment e ON g.EnrollmentID = e.EnrollmentID 
WHERE g.Score < 50;

-- List all teachers who have more than 10 years of experience.
SELECT TeacherID, FirstName, LastName, HireDate 
FROM teacher 
WHERE DATEDIFF(CURDATE(), HireDate) > 3650;

-- What is the total number of students in each grade level?
SELECT g.GradeName, COUNT(s.StudentID) AS StudentCount 
FROM gradelevel g 
JOIN student s ON g.GradeLevelID = s.GradeLevelID 
GROUP BY g.GradeName;

-- List all students along with their scores in a specific exam.
SELECT s.StudentID, s.FirstName, s.LastName, g.Score 
FROM student s 
JOIN enrollment e ON s.StudentID = e.StudentID 
JOIN grade g ON e.EnrollmentID = g.EnrollmentID 
WHERE g.ExamID = 1;

-- What is the average score of students in each exam type?
SELECT e.ExamType, AVG(g.Score) AS AverageScore 
FROM exam e 
JOIN grade g ON e.ExamID = g.ExamID 
GROUP BY e.ExamType;

-- List all courses along with the number of teachers assigned.
SELECT c.CourseName, COUNT(DISTINCT c.TeacherID) AS TeacherCount 
FROM course c 
GROUP BY c.CourseName;

-- What is the total number of students who have attended at least one class?
SELECT COUNT(DISTINCT e.StudentID) 
FROM attendance a 
JOIN enrollment e ON a.EnrollmentID = e.EnrollmentID;

-- List all students along with their attendance percentage.
SELECT s.StudentID, s.FirstName, s.LastName, 
(SUM(CASE WHEN a.Status = 'Present' THEN 1 ELSE 0 END) / COUNT(a.AttendanceID)) * 100 AS AttendancePercentage 
FROM student s 
JOIN enrollment e ON s.StudentID = e.StudentID 
JOIN attendance a ON e.EnrollmentID = a.EnrollmentID 
GROUP BY s.StudentID;

-- What is the total number of subjects in each grade level?
SELECT g.GradeName, COUNT(DISTINCT s.SubjectID) AS SubjectCount 
FROM gradelevel g 
JOIN course c ON g.GradeLevelID = c.GradeLevelID 
JOIN subject s ON c.SubjectID = s.SubjectID 
GROUP BY g.GradeName;

-- List all classrooms along with the number of students in each.
SELECT cl.ClassroomName, COUNT(e.StudentID) AS StudentCount 
FROM classroom cl 
JOIN classschedule cs ON cl.ClassroomID = cs.ClassroomID 
JOIN course c ON cs.CourseID = c.CourseID 
JOIN enrollment e ON c.CourseID = e.CourseID 
GROUP BY cl.ClassroomName;

-- What is the average score of each student in a specific section?
SELECT s.StudentID, s.FirstName, s.LastName, AVG(g.Score) AS AverageScore 
FROM student s 
JOIN enrollment e ON s.StudentID = e.StudentID 
JOIN course c ON e.CourseID = c.CourseID 
JOIN grade g ON e.EnrollmentID = g.EnrollmentID 
WHERE c.SectionID = 1 
GROUP BY s.StudentID;

-- List all teachers along with their birthdates and gender.
SELECT TeacherID, FirstName, LastName, DateOfBirth, Gender 
FROM teacher;

-- What is the total number of students who have scored below 70 in any exam?
SELECT COUNT(DISTINCT e.StudentID) 
FROM grade g 
JOIN enrollment e ON g.EnrollmentID = e.EnrollmentID 
WHERE g.Score < 70;

-- List all students who have scored exactly 100 in any exam.
SELECT DISTINCT s.StudentID, s.FirstName, s.LastName 
FROM student s 
JOIN enrollment e ON s.StudentID = e.StudentID 
JOIN grade g ON e.EnrollmentID = g.EnrollmentID 
WHERE g.Score = 100;

-- What is the total number of classrooms in each grade level?
SELECT g.GradeName, COUNT(DISTINCT cl.ClassroomID) AS ClassroomCount 
FROM gradelevel g 
JOIN course c ON g.GradeLevelID = c.GradeLevelID 
JOIN classschedule cs ON c.CourseID = cs.CourseID 
JOIN classroom cl ON cs.ClassroomID = cl.ClassroomID 
GROUP BY g.GradeName;

-- List all teachers along with their subjects and sections.
SELECT t.TeacherID, t.FirstName, t.LastName, s.SubjectName, se.SectionName 
FROM teacher t 
JOIN subject s ON t.SubjectID = s.SubjectID 
JOIN course c ON t.TeacherID = c.TeacherID 
JOIN section se ON c.SectionID = se.SectionID;

-- What is the average score of each student in each course?
SELECT s.StudentID, s.FirstName, s.LastName, c.CourseName, AVG(g.Score) AS AverageScore 
FROM student s 
JOIN enrollment e ON s.StudentID = e.StudentID 
JOIN course c ON e.CourseID = c.CourseID 
JOIN grade g ON e.EnrollmentID = g.EnrollmentID 
GROUP BY s.StudentID, c.CourseName;

-- List all subjects along with the number of teachers assigned.
SELECT s.SubjectName, COUNT(t.TeacherID) AS TeacherCount 
FROM subject s 
JOIN teacher t ON s.SubjectID = t.SubjectID 
GROUP BY s.SubjectName;

-- What is the total number of students who have not attended any classes?
SELECT COUNT(DISTINCT e.StudentID) 
FROM enrollment e 
LEFT JOIN attendance a ON e.EnrollmentID = a.EnrollmentID 
WHERE a.AttendanceID IS NULL;

-- List all exams along with their average scores.
SELECT e.ExamID, e.CourseID, AVG(g.Score) AS AverageScore 
FROM exam e 
JOIN grade g ON e.ExamID = g.ExamID 
GROUP BY e.ExamID;

-- What is the total number of students in each subject?
SELECT s.SubjectName, COUNT(e.StudentID) AS StudentCount 
FROM subject s 
JOIN course c ON s.SubjectID = c.SubjectID 
JOIN enrollment e ON c.CourseID = e.CourseID 
GROUP BY s.SubjectName;

-- List all teachers along with the number of students they teach.
SELECT t.TeacherID, t.FirstName, t.LastName, COUNT(e.StudentID) AS StudentCount 
FROM teacher t 
JOIN course c ON t.TeacherID = c.TeacherID 
JOIN enrollment e ON c.CourseID = e.CourseID 
GROUP BY t.TeacherID;

-- What is the average score of each student in a specific grade level?
SELECT s.StudentID, s.FirstName, s.LastName, AVG(g.Score) AS AverageScore 
FROM student s 
JOIN enrollment e ON s.StudentID = e.StudentID 
JOIN grade g ON e.EnrollmentID = g.EnrollmentID 
WHERE s.GradeLevelID = 1 
GROUP BY s.StudentID;

-- List all courses along with their teachers and schedules.
SELECT c.CourseName, t.FirstName, t.LastName, cs.DayOfWeek, cs.StartTime, cs.EndTime 
FROM course c 
JOIN teacher t ON c.TeacherID = t.TeacherID 
JOIN classschedule cs ON c.CourseID = cs.CourseID;

-- What is the total number of students who have scored above the average score in any exam?
SELECT COUNT(DISTINCT e.StudentID) 
FROM grade g 
JOIN enrollment e ON g.EnrollmentID = e.EnrollmentID 
JOIN (
    SELECT ExamID, AVG(Score) AS AvgScore 
    FROM grade 
    GROUP BY ExamID
) AS exam_avg ON g.ExamID = exam_avg.ExamID 
WHERE g.Score > exam_avg.AvgScore;

-- List all teachers along with the number of years they have been teaching.
SELECT TeacherID, FirstName, LastName, DATEDIFF(CURDATE(), HireDate) / 365 AS YearsTeaching 
FROM teacher;

-- What is the total number of students who have attended more than 75% of their classes?
SELECT COUNT(DISTINCT s.StudentID) 
FROM student s 
JOIN enrollment e ON s.StudentID = e.StudentID 
JOIN attendance a ON e.EnrollmentID = a.EnrollmentID 
JOIN (
    SELECT e.EnrollmentID, COUNT(*) AS TotalClasses 
    FROM classschedule cs 
    JOIN course c ON cs.CourseID = c.CourseID 
    JOIN enrollment e ON c.CourseID = e.CourseID 
    GROUP BY e.EnrollmentID
) AS class_counts ON e.EnrollmentID = class_counts.EnrollmentID 
GROUP BY s.StudentID 
HAVING (SUM(CASE WHEN a.Status = 'Present' THEN 1 ELSE 0 END) / class_counts.TotalClasses) > 0.75;
List all courses along with the number of male and female students enrolled.
sql SELECT c.CourseName, SUM(CASE WHEN s.Gender = 'Male' THEN 1 ELSE 0 END) AS MaleStudents, SUM(CASE WHEN s.Gender = 'Female' THEN 1 ELSE 0 END) AS FemaleStudents FROM course c JOIN enrollment e ON c.CourseID = e.CourseID JOIN student s ON e.StudentID = s.StudentID GROUP BY c.CourseName;